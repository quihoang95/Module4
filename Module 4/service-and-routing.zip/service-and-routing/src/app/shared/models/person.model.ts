export interface Person {
  id: number;
  name: string;
  age: number;
  address: string;
}
