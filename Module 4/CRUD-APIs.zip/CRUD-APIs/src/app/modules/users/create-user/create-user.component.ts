import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UsersService } from '../users.service';

@Component({
  selector: 'app-create-user',
  template: `
    <form [formGroup]="userForm" (ngSubmit)="submitForm()">
      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="inputName">Name</label>
          <input formControlName="name" type="text" class="form-control" id="inputName" placeholder="Name">
          <div *ngIf="getControl('name').hasError()" class="invalid-feedback">Please fill out this field.</div>
        </div>
        <div class="form-group col-md-6">
          <label for="username">Username</label>
          <input formControlName="username" type="text" class="form-control" id="username" placeholder="Username">
        </div>
      </div>
      <div class="form-group">
        <label for="inputEmail">Email</label>
        <input formControlName="email" type="email" class="form-control" id="inputEmail" placeholder="Email">
      </div>
      <div class="form-group">
        <label for="inputPhone">Phone</label>
        <input formControlName="phone" type="text" class="form-control" id="inputPhone" placeholder="Phone">
      </div>  

      <button type="submit" class="btn btn-primary">Sign in</button>
    </form>
  `,
  styles: [
    `
      form {
        padding: 1rem;
      }
    `
  ]
})
export class CreateUserComponent implements OnInit {
  userForm: FormGroup;

  constructor(
    private readonly formBuilder: FormBuilder,
    private userService: UsersService,
    private router: Router
  ) {

  }

  ngOnInit(): void {
    this.userForm = this.formBuilder.group({
      name: [null, [Validators.required, Validators.maxLength(100), Validators.minLength(2)]],
      username: [null, [Validators.required, Validators.maxLength(100), Validators.minLength(2)]],
      phone: [null, [Validators.required, Validators.maxLength(20), Validators.minLength(9)]],
      email: [null, [Validators.pattern(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/)]]
    })
  }

  submitForm() {
    const user = this.userForm.value;
    this.userService.create(user).subscribe(
      res => {
        alert("Create user success!");
        this.router.navigateByUrl("/users");
      }
    )
  }

  getControl(controlName: string) {
    return this.userForm.get(controlName);
  }
}
