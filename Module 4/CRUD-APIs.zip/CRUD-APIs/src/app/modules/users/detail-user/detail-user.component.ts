import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/shared/models/user.model';
import { UsersService } from '../users.service';

@Component({
  selector: 'app-detail-user',
  template: `
    <p>
      Name: {{ user?.name }}
    </p>
    <p>
      Username: {{ user?.username }}
    </p>
    <p>
      Email: {{ user?.email }}
    </p>
    <p>
      Address: {{ user?.address?.street }}, {{ user?.address?.city}}
    </p>
  `,
  styles: [
    `
      :host {
        display: block;
        padding: 1rem;
      }
    `
  ]
})
export class DetailUserComponent implements OnInit {
  user: User = null;

  constructor(
    private readonly userService: UsersService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    // Get Id From URL Param
    const id: number = +this.route.snapshot.paramMap.get("id");

    // Fetch User Data from API
    this.userService.getById(id).subscribe(
      res => {
        this.user = res
      },
      err => {
        // If error is not found, redirect to 404 page
        if(err.status === 404)
          this.router.navigate(["/error-not-found"]);
      }
    )
    
  }

}
