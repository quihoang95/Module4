import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/shared/models/user.model';
import { UsersService } from '../users.service';

@Component({
  selector: 'app-list-user',
  template: `
    <table class="table table-striped">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Name</th>
          <th scope="col">Username</th>
          <th scope="col">Email</th>
          <th scope="col">Actiosn</th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let user of userList; index as idx">
          <th scope="row">{{ idx + 1 }}</th>
          <td>{{ user.name }}</td>
          <td>{{ user.username }}</td>
          <td>{{ user.email }}</td>
          <td>
            <button (click)="deleteUser(user.id)" class="btn btn-danger">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
  `,
  styles: [
  ]
})
export class ListUserComponent implements OnInit {
  userList: User[] = []

  constructor(private readonly userService: UsersService) { }

  ngOnInit(): void {
    this.userService.getAll().subscribe(
      res => this.userList = res
    )
  }

  deleteUser(id: number) {
    console.log("Call Delete User" + id)
    this.userService.delete(id).subscribe(
      res => {
        this.userList = this.userList.filter(user => user.id !== id)
      }
    )
  }
}
