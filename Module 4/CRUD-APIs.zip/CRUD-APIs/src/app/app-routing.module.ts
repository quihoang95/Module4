import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/users',
    pathMatch: 'full'
  },
  { 
    path: 'users', loadChildren: () => import('./modules/users/users.module')
      .then(m => m.UsersModule)
  },
  { path: 'error-not-found', loadChildren: () => import('./shared/pages/error404/error404.module').then(m => m.Error404Module) }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
